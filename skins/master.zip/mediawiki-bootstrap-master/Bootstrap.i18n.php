<?php
/**
 * Internationalization file for skin Bootstrap.
 *
 * @file
 * @ingroup Skins
*/

	$messages = array();
	
	/** English
	* @author Matt Yeh
	*/
	$messages['en'] = array(
		'skinname-bootstrap' => "Bootstrap",
		'bootstrap-desc' => "Bootstrap skin",
	);
